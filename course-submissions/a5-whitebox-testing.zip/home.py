"""
This is implemented for documentation purposes. This class represents the Home page of the web app.
It would display information, and could guide you to anything within the system. This class would contain
information and prompts for the backend to be accessed/used. 
This class for the purpose of Assignment 2 is just a placeholder.
"""
print("Welcome to the Homepage!")
